<?php 

require 'conn/koneksi.php';

$username = $_POST["username"];
$password = $_POST["password"];


$result = mysqli_query($koneksi, "SELECT * FROM petugas WHERE username = '$username' AND password = '$password' ");
$cek = mysqli_num_rows($result);

if ($cek>0) {
    $data = mysqli_fetch_array($result);
    if($data['level'] == 'admin') {
        session_start();
        $_SESSION['id_petugas'] = $data['id_petugas'];
        $_SESSION['username'] = $username;
        $_SESSION['nama_petugas'] = $data['nama_petugas'];
        $_SESSION['level'] = $data['level'];

        header('Location: admin/admin.php');
    } else if($data['level'] == 'petugas') { 
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['nama_petugas'] = $data['nama_petugas'];
        $_SESSION['level'] = $data['level'];

        header('Location: petugas/petugas.php');
    }
} else {
    echo "<script>
        alert('Username atau Password tidak ditemukan!');
        window.location='login_petugas.php';
    </script>"; 
}
 
?>

<script type="text/javascript" src="js/sweetalert2.all.min.js"></script>