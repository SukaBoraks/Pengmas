<?php 
require 'conn/koneksi.php';

$nik = $_POST['nik'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$telp = $_POST['telp'];
$foto_profile = $_POST['foto_profile'];

$query = "INSERT INTO masyarakat VALUES('$nik', '$nama', '$username', '$password', '$telp', '$foto_profile')";
mysqli_query($koneksi, $query);

if($query) {
    echo "<script>
        alert('Data berhasil disimpan. Silahkan gunakan untuk login');
        window.location='index.php';
    </script>";
} else {
    echo "<script>
        alert('Data gagal');
    </script>";
}

?>