<?php 

require 'conn/koneksi.php';

$username = $_POST["username"];
$password = $_POST["password"];


$result = mysqli_query($koneksi, "SELECT * FROM masyarakat WHERE username = '$username' AND password = '$password' ");
$cek = mysqli_num_rows($result);

if ($cek>0) {
    $data = mysqli_fetch_array($result);
    session_start();
    $_SESSION['id_pengaduan'] = $pengaduan['id_pengaduan'];
    $_SESSION['nama'] = $username;
    $_SESSION['nik'] = $data['nik'];
    header('Location: masyarakat/masyarakat.php');
} else {
    echo "<script>
        alert('Username atau Password tidak ditemukan!');
        window.location='index.php';
    </script>"; 
}
 
?>