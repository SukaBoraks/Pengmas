<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <div class="container">
        <img src="../img/aduan.png" style="margin: 20px 320px; border-radius: 5px; border: 1px solid rgba(0,0,0,0.5);">
        <h3 style="text-align: center; margin-top: 20px;">Selamat Datang di Aplikasi Pengaduan Masyarakat</h3> 
        <p style="text-align: center;">Aplikasi pengaduan masyarakat dapat memudahkan masyarakat untuk melakukan pengaduan tanpa harus datang ke desa</p>
        <p style="text-align: center; font-size: small; margin-top: -10px;">Dibuat Oleh Fharhan Fariz Untuk Keperluan Ujikom</p>
        <h6 style="text-align: center; font-weigth: bold;">Anda login sebagai <?= $_SESSION['nama']; ?></h6>
    </div>
</body>
</html>
