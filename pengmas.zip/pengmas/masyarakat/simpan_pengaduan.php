<?php 
require '../conn/koneksi.php';

$tgl_pengaduan = date('Y-m-d');
$nik = $_POST['nik'];
$isi_laporan = $_POST['isi_laporan'];
$foto = $_FILES['foto']['name'];
$file = $_FILES['foto']['tmp_name'];
$status = 0;

$query = "INSERT INTO pengaduan_ (tgl_pengaduan, nik, isi_laporan, foto, status) VALUES ('$tgl_pengaduan', '$nik', '$isi_laporan', '$foto', '$status')";
mysqli_query($koneksi, $query);
 
move_uploaded_file($file, '../img/'.$foto); 

if($query) {
    echo "<script>
        alert('Data berhasil disimpan! Terima kasih sudah menulis laporan pengaduan');
        window.location='masyarakat.php';
    </script>";
}  

?>   
 