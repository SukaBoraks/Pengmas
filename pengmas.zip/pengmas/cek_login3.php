<?php
session_start();
include 'conn/koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);
$level = $_POST['level'];

$login = mysqli_query($koneksi, "SELECT * FROM petugas WHERE username = '$username' AND password = '$password' ");

$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    if ($data ['level'] == 'admin') {
        $_SESSION['id_petugas'] = $data['id_petugas'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['login'] = 'admin';
        header('Location: admin/admin.php');
    } elseif ($data ['level'] == 'petugas') {
        $_SESSION['id_petugas'] = $data['id_petugas'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['login'] = 'petugas';
        header('Location: petugas/petugas.php');
    }
} else {
    echo "<script>
        alert('Username atau Password tidak ditemukan!');
        window.location='login_petugas.php';
    </script>"; 
}

?>