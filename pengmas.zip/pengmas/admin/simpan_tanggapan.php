<?php 
require '../conn/koneksi.php';

$id_pengaduan = $_POST['id_pengaduan'];
$tgl_tanggapan = $_POST['tgl_tanggapan'];
$tanggapan = $_POST['tanggapan'];
$id_petugas = $_POST['id_petugas'];
$status = 'selesai';

$query = mysqli_query($koneksi, "INSERT INTO tanggapan(id_pengaduan, tgl_tanggapan, tanggapan, id_petugas) VALUES('$id_pengaduan', '$tgl_tanggapan', '$tanggapan', '$id_petugas') ");

$update_status = mysqli_query($koneksi, "UPDATE pengaduan_ SET status = '$status' WHERE id_pengaduan = '$id_pengaduan' ");

if ($query) {
    echo "
    <script type='text/javascript'>
        alert('Data sudah ditanggapi');
        window.location='admin.php?page=verifikasi_pengaduan';
    </script>
    ";
}

?>
