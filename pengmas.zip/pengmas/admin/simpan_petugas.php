<?php 
require '../conn/koneksi.php';

$nama_petugas = $_POST['nama_petugas'];
$username = $_POST['username'];
$password = $_POST['password'];
$telp = $_POST['telp'];
$level = $_POST['level'];

$query = mysqli_query($koneksi, "INSERT INTO petugas(nama_petugas, username, password, telp, level) VALUES('$nama_petugas', '$username', '$password', '$telp', '$level') ");

if ($query) {
    echo "
    <script type='text/javascript'>
        alert('Petugas berhasil ditambahkan');
        window.location='admin.php?page=lihat_petugas';
    </script>
    ";
}

?>