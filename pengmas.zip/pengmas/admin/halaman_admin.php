<?php 
require('../conn/koneksi.php');
$query = "SELECT * FROM petugas ";
$result = mysqli_query($koneksi, $query);

if($cek = mysqli_num_rows($result)) {

}

$query2 = "SELECT * FROM masyarakat ";
$result2 = mysqli_query($koneksi, $query2);

if($cek2 = mysqli_num_rows($result2)) {

}

$query3 = "SELECT * FROM pengaduan_";
$result3 = mysqli_query($koneksi, $query3);

if($cek3 = mysqli_num_rows($result3)) {

}

$query4 = "SELECT * FROM tanggapan";
$result4 = mysqli_query($koneksi, $query4);

if($cek4 = mysqli_num_rows($result4)) {

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Petugas</title>
</head>
<body>
    <div class="container">
        <div class="kotak">
            <img src="../img/aduan.png" style="margin: 0px 320px 20px; border-radius: 50px; ">
        </div>       
        <div class="container-fluid">
            <div class="row">

            <!-- kartu Bagian Data Petugas -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><a href="admin.php?page=lihat_petugas">Data Petugas</a></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800" style="font-size: small; padding-top: 15px;">Ada <?= $cek; ?> Petugas</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user fa-2x text-gray-300"></i>
                                <span class="badge badge-primary badge-counter">
                                    <?= $cek; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- kartu Bagian Data Masyarakat -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1"><a href="admin.php?page=lihat_masyarakat" class="text-success">Data Masyarakat</a></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800" style="font-size: small; padding-top: 15px;">Ada <?= $cek2; ?> Masyarakat</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-users fa-2x text-gray-300"></i>
                                <span class="badge badge-success badge-counter">
                                    <?= $cek2; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- kartu Bagian Data Pengaduan -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1"><a href="admin.php?page=lihat_data_pengaduan" class="text-info">Data Pengaduan</a></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800" style="font-size: small; padding-top: 15px;">Ada <?= $cek3; ?> Data Pengaduan</div>
                            </div>                     
                            <div class="col-auto">
                                <i class="fas fa-comments fa-2x text-gray-300"></i>
                                <span class="badge badge-info badge-counter">
                                    <?= $cek3; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- kartu Bagian Data Tanggapan -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1"><a href="admin.php?page=lihat_data_tanggapan" class="text-warning">Data Tanggapan</a></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800" style="font-size: small; padding-top: 15px;">Ada <?= $cek4; ?> Data Tanggapan</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-comments fa-2x text-gray-300"></i>
                                <span class="badge badge-warning badge-counter">
                                    <?= $cek4; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>

        <h3 style="text-align: center; margin-top: 20px;">Selamat Datang di Aplikasi Pengaduan Masyarakat</h3> 
        <p style="text-align: center;">Aplikasi pengaduan masyarakat dapat memudahkan masyarakat untuk melakukan pengaduan tanpa harus datang ke desa</p>
        <p style="text-align: center; font-size: small; margin-top: -10px;">Dibuat Oleh Fharhan Fariz Untuk Keperluan Ujikom</p>

        <h6 style="text-align: center; font-weigth: bold;">Anda login sebagai <?= $_SESSION['nama_petugas']; ?></h6>
    </div>
</body>
</html>
