<?php 
require '../conn/koneksi.php';
$id_petugas = $_GET['id_petugas'];

$hapus = mysqli_query($koneksi, "DELETE FROM petugas WHERE id_petugas = '$id_petugas' ");

if ($hapus) {
    echo "
    <script type='text/javascript'>
        alert('Petugas berhasil dihapus');
        window.location='admin.php?page=lihat_petugas';
    </script>
    ";
}

?>