<?php 
require '../conn/koneksi.php';

$nama_petugas = $_POST['nama_petugas'];
$username = $_POST['username'];
$password = $_POST['password'];
$telp = $_POST['telp'];
$level = $_POST['level'];
$id_petugas = $_POST['id_petugas'];

$query = mysqli_query($koneksi, "UPDATE petugas SET 
                        nama_petugas = '$nama_petugas', 
                        username = '$username', 
                        password = '$password', 
                        telp = '$telp', 
                        level = '$level' 
                        WHERE id_petugas = '$id_petugas' ");

if ($query) {
    echo "
    <script type='text/javascript'>
        alert('Data petugas berhasil diubah');
        window.location='admin.php?page=lihat_petugas';
    </script>
    ";
}

?>