<?php 
require '../conn/koneksi.php';
$id = $_GET['id_pengaduan'];

$hapus = mysqli_query($koneksi, "DELETE FROM pengaduan_ WHERE id_pengaduan = '$id' ");

if ($hapus) {
    echo "
    <script type='text/javascript'>
        alert('Pengaduan berhasil dihapus');
        window.location='masyarakat.php?page=lihat_pengaduan';
    </script>
    ";
}

?>