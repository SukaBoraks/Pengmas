<?php 
require('../conn/koneksi.php');
$query = "SELECT * FROM pengaduan_ WHERE status='0'";
$result = mysqli_query($koneksi, $query);

if($cek = mysqli_num_rows($result)) {

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Petugas</title>
    <style>
        .kotak {
            display: flex;
            margin: 10px auto;
        }
        .kotak img {
            height: 120px;
            border-radius: 5px;
            border: 1px solid rgba(0,0,0, 0.5);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="kotak">
            <img src="../img/aduan.png">
            <div class="col-xl-6 col-md-6 mb-4 mx-3">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Laporan Pengaduan Masuk :</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">Ada <?= $cek; ?> Laporan dari masyarakat</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-comments fa-4x text-gray-300"></i>
                                <span class="badge badge-danger badge-counter">
                                    <?= $cek; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>       
        <h3 style="text-align: center; margin-top: 20px;">Selamat Datang di Aplikasi Pengaduan Masyarakat</h3> 
        <p style="text-align: center;">Aplikasi pengaduan masyarakat dapat memudahkan masyarakat untuk melakukan pengaduan tanpa harus datang ke desa</p>
        <p style="text-align: center; font-size: small; margin-top: -10px;">Dibuat Oleh Fharhan Fariz Untuk Keperluan Ujikom</p>

        <h6 style="text-align: center; font-weigth: bold;">Anda login sebagai <?= $_SESSION['nama_petugas']; ?></h6>
    </div>
</body>
</html>
