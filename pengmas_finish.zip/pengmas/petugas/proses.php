<?php 
require('../conn/koneksi.php');

$id_pengaduan = $_GET['id_pengaduan'];
$status = 'proses';

$query = mysqli_query($koneksi, "UPDATE pengaduan_ SET status = '$status' WHERE id_pengaduan = '$_GET[id_pengaduan]' ");

if($query) {
    echo "
    <script type='text/javascript'>
        alert('Data berhasil diverifikasi');
        window.location='?page=verifikasi_pengaduan';
    </script>
    ";
}

?>