<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>PENGMAS == Edit Petugas ==</title>

  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Edit Petugas</h6>
    </div>
    <div class="card-body">

        <?php 
        require '../conn/koneksi.php';

        $query = mysqli_query($koneksi, "SELECT * FROM petugas WHERE id_petugas = '$_GET[id_petugas]' ");

        if ($data = mysqli_fetch_array($query)) : {

        }

        ?>

        <a href="?page=lihat_petugas" class="btn btn-primary btn-icon-split mb-3">
            <span class="icon text-white-50">
                <i class="fas fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
        
        <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
            <div class="form-group cols-sm-6">
                <label>Id Petugas</label>
                <input type="text" name="id_petugas" value="<?= $data['id_petugas']; ?>" class="form-control" readonly>
            </div>
            <div class="form-group cols-sm-6">
                <label>Nama Petugas</label>
                <input type="text" name="nama_petugas" value="<?= $data['nama_petugas']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Username</label>
                <input type="text" name="username" value="<?= $data['username']; ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>No Telepon</label>
                <input type="text" name="telp" value="<?= $data['telp'] ?>" class="form-control">
            </div>
            <div class="form-group cols-sm-6">
                <label>Level</label>
                <select class="form-control" name="level">
                    <option value="<?= $data['level']; ?>">== <?= $data['level']; ?> ==</option>
                    <option value="admin">Administrator</option>
                    <option value="petugas">Petugas</option>
                </select>
            </div>
            <div class="form-group cols-sm-6">
                <input type="submit" name="update" value="Simpan Perubahan " class="btn btn-primary">
                <input type="reset" value="Kosongkan " class="btn btn-warning">
            </div>
        </form>
        <?php endif; ?>
        <?php 
        require '../conn/koneksi.php';

        if(isset($_POST['update'])){
            $nama_petugas = $_POST['nama_petugas'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $telp = $_POST['telp'];
            $level = $_POST['level'];
            $id_petugas = $_POST['id_petugas'];

            $query = mysqli_query($koneksi, "UPDATE petugas SET 
                                    nama_petugas = '$nama_petugas', 
                                    username = '$username', 
                                    password = '$password', 
                                    telp = '$telp', 
                                    level = '$level' 
                                    WHERE id_petugas = '$id_petugas' ");

            if ($query) {
                echo "
                <script type='text/javascript'>
                    alert('Data petugas berhasil diubah');
                    window.location='admin.php?page=lihat_petugas';
                </script>
                ";
            }
        }

        ?>
    </div>
</div>








<!-- Bootstrap core JavaScript-->
<script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

</body>

</html>
