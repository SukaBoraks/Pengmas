<?php 
require '../conn/koneksi.php';
$nik = $_GET['nik'];

$hapus = mysqli_query($koneksi, "DELETE FROM masyarakat WHERE nik = '$nik' ");

if ($hapus) {
    echo "
    <script type='text/javascript'>
        alert('Masyarakat berhasil dihapus');
        window.location='admin.php?page=lihat_masyarakat';
    </script>
    ";
}

?>