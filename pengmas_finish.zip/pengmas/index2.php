<?php 

// if(isset($_SESSION['nik']) ==  true){
//    header('location: pages/dashboard.php');
// }

// if(isset($_POST['login'])){
//   $nik = $_POST['nik'];
//   $pass = $_POST['pass'];
//   if(!$nik || !$pass){
//     echo"";
//   }else{
//       $format = "$nik|$pass";
//       $file = file('db/user.txt', FILE_IGNORE_NEW_LINES);
//       if(in_array($format, $file)){
//           session_start();
//           $_SESSION['nik'] = $nik;
//           header("location: pages/dashboard.php");
//       }else{
//           echo"<div class='alert alert-danger text-center px-5' style='padding: 5 100px' role='alert'>
//           NIK ATAU PASSWORD SALAH
//           </div>";
//       }
//   }
// }


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PD | LOGIN</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="font/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="icheck/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/sb-admin-2.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <a href="" class="h1"><b>Peduli Diri</b> Login</a>
    </div>
    <div class="card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form action="" method="post">
        <div class="input-group mb-3">
          <input type="number" class="form-control" placeholder="Nik" name="nik">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="pass">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
        
          <!-- /.col -->
          <div class="col-4 mx-auto">
            <button type="submit" class="btn btn-primary btn-block" name="login">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <p class="mb-0">
        <a href="register.php" class="text-center d-block mx-auto">Register a new membership</a>
      </p>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="template/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="template/dist/js/adminlte.min.js"></script>
</body>
</html>
